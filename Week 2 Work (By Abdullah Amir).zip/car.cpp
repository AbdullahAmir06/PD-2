#include<iostream>
using namespace std;
main()
{
system("color 80");
cout<<"                __________________                 "<<endl;
cout<<"               /  _______________ \\               "<<endl;
cout<<"              /  /_      ||      \\ \\             "<<endl;
cout<<"   __________/  /__|_____||_______\\ \\____________   "<<endl;
cout<<"  |    _____    |       =||     =  | _____     _|  "<<endl;
cout<<"  |   /     \\   |        ||       / /     \\   /_|  "<<endl;
cout<<"  |__/   .   \\__|________||______/_/   .   \\____|  "<<endl;
cout<<"     \\       /                     \\       /        "<<endl;
cout<<"      \\_____/                       \\_____/         "<<endl;
}