#include<iostream>
using namespace std;
main()
{
system("color 8F");
cout<<"----------------------    "<<endl;
cout<<"    o   ^__^              "<<endl;
cout<<"     o  (oo)\\_____       "<<endl;
cout<<"        (__)\\     )\\/\\ "<<endl;
cout<<"            ||----w |     "<<endl;
cout<<"            ||     ||     "<<endl;

}