#include<iostream>
using namespace std;
main()
{
 system("color 9F");
cout<<"      .::---::..   "<< endl;
cout<<"   .------------.  "<< endl;
cout<<" .---------------. "<< endl;
cout<<" --------------:.  "<< endl;
cout<<":---------::.      "<< endl;
cout<<"---------:.        "<< endl;
cout<<":-----------:..    "<< endl;
cout<<" :--------------:. "<< endl;
cout<<"  .-------------:  "<< endl;
cout<<"    .:-------:.    "<< endl;
}