#include<iostream>
using namespace std;
main()
{
 system("color F0");
cout<<"                       ___..............._                                         "<<endl;
cout<<"               __.. '_'.]]- .'-._                                                  "<<endl;
cout<<"     ______.-'      (_) |      ]]           ']]'-. _                               "<<endl;
cout<<"    /_       ___________,_______]]___...._____]]__'.'  -..___                      "<<endl;
cout<<"    |                                          |              '--. _               "<<endl;
cout<<"    | T      _.----._        Xxx|x...          |         _.._          -._         "<<endl;
cout<<"    | |    .' ..--.. '.      XXX|XXXXXXXXXxx== |       .'.---..'.                  "<<endl;
cout<<"    ]_;   /  /  __  )  )     XXX|XXXXXXXXXxx==       / /  --    ) )        '-.     "<<endl;
cout<<"     _|  |  |  /  )  |  |    XXX|'           |    | |  /   )   | |          |      "<<endl;
cout<<"    |__)_|  |  (__/  |  |_______|______________|____| |   (__/   | |__________J    "<<endl;
cout<<"         '')(       / ./_____________________________( (       / /__________)      "<<endl;
cout<<"            '.'----'     dp                            '.'____'.'                  "<<endl;
cout<<"              ,,                                     ,,                            "<<endl;
}
