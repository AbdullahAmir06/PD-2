#include<iostream>
using namespace std;
main()
{
system("color 0F");
cout<<"           *     *     *                     "<<endl;
cout<<"            *     *     *                    "<<endl;
cout<<"             *     *     *                   "<<endl;
cout<<"            *     *     *                    "<<endl;
cout<<"           *     *     *                     "<<endl;
cout<<"          *     *     *                      "<<endl;
cout<<"           *     *     *                     "<<endl;
cout<<"            *     *     *                    "<<endl;
cout<<"             *     *     *                   "<<endl;
cout<<"      *****************************          "<<endl;
cout<<"       *                         *           "<<endl;
cout<<"        *                       *            "<<endl;
cout<<"         *                     *             "<<endl;
cout<<"          *                   *              "<<endl;
cout<<"           *******************               "<<endl; 
cout<<"                                             "<<endl;
cout<<"                                             "<<endl;
cout<<"  ttWELCOME TO F()():)Y APPLICATITIONtt      "<<endl;
}